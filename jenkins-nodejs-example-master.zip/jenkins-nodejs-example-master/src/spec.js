import '.';

import { describe, it } from 'mocha';
import { expect } from 'chai';

describe('project', () => {
  it('imports without errors', () => {
    expect(true).to.be.true;
  });
});
