# Node.js App with Jenkinsfile

This sample project demonstrates how a Jenkinsfile can be written for a Node.js application.
